# Inspector Summary

- gradient_closed: `True`
- credit_closed: `False`
- bad_grad_groups: `[]`
- bad_credit_stages: `['recovery']`
