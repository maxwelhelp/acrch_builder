# AGENT_CONTEXT

## Runtime truth

- gradient_closed: `True` bad=`[]`
- credit_closed: `False` bad=`['recovery']` broken=`['edge_active->recovery', 'recovery->loss_connected']`

## Static loops

- `main_learning_loop` static_closed=`True` missing_roles=`[]` missing_edges=`[]`
- `simulator_choice_loop` static_closed=`True` missing_roles=`[]` missing_edges=`[]`
- `memory_state_loop` static_closed=`True` missing_roles=`[]` missing_edges=`[]`
- `report_agent_loop` static_closed=`True` missing_roles=`[]` missing_edges=`[]`

## Risk nodes

- `entrypoint` role=`entrypoint` degree=`81` file=`` line=``
- `tools/agent_codegraph/build_agent_codegraph.py` role=`scanner` degree=`43` file=`` line=``
- `parser` role=`entrypoint` degree=`40` file=`arch_builder/train_vertical_slice.py` line=`607`
- `main` role=`entrypoint` degree=`39` file=`tools/project_probe/probe_learning_loop.py` line=`41`
- `tools/build_code_logic_graph.py` role=`scanner` degree=`35` file=`` line=``
- `memory` role=`memory` degree=`35` file=`` line=``
- `ActionMatrixLayer.__init__` role=`controller` degree=`34` file=`arch_builder/model.py` line=`29`
- `tools/agent_inspector/inspect_project.py` role=`memory` degree=`32` file=`` line=``
- `controller` role=`controller` degree=`31` file=`` line=``
- `ActionMatrixLayer.forward` role=`controller` degree=`27` file=`arch_builder/model.py` line=`78`
- `arch_builder/train_vertical_slice.py` role=`data` degree=`25` file=`` line=``
- `tools/agent_inspector/runtime_probe.py` role=`entrypoint` degree=`23` file=`` line=``
- `HybridScanner.__init__` role=`scanner` degree=`22` file=`arch_builder/hybrid_scanner.py` line=`14`
- `train` role=`reporting` degree=`22` file=`arch_builder/train_vertical_slice.py` line=`473`
- `FuncVisitor._target` role=`memory` degree=`21` file=`tools/agent_codegraph/build_agent_codegraph.py` line=`188`
- `FV._target` role=`memory` degree=`21` file=`tools/agent_inspector/inspect_project.py` line=`84`
- `FuncVisitor._target` role=`memory` degree=`21` file=`tools/build_code_logic_graph.py` line=`133`
- `ActionMatrixModel.__init__` role=`model_core` degree=`20` file=`arch_builder/model.py` line=`182`
- `arch_builder/model.py` role=`controller` degree=`19` file=`` line=``
- `scanner` role=`scanner` degree=`19` file=`` line=``
- `ActionExecutor.__init__` role=`executor` degree=`18` file=`arch_builder/executor.py` line=`12`
- `arch_builder/primitive_matrix.py` role=`primitive_matrix` degree=`18` file=`` line=``
- `PrimitiveMatrix5x5.__init__` role=`primitive_matrix` degree=`18` file=`arch_builder/primitive_matrix.py` line=`63`
- `build_graph` role=`memory` degree=`18` file=`tools/agent_codegraph/build_agent_codegraph.py` line=`240`
- `HybridScanner.forward` role=`scanner` degree=`17` file=`arch_builder/hybrid_scanner.py` line=`42`

## Probe metrics

- `loss`: `7.127186298370361`
- `ce`: `0.7085954546928406`
- `sim_loss`: `0.0442097969353199`
- `expected_choice_loss`: `6.303151607513428`
- `expected_active_loss`: `1.715549111366272`
- `non_expected_primitive_loss`: `0.020496468991041183`
- `non_expected_active_loss`: `0.2052440643310547`
- `non_expected_tape_loss`: `0.06377014517784119`
- `non_expected_transform_loss`: `0.5580520629882812`
- `primitive_usage_diversity`: `0.0`
- `cell_choice_diversity`: `0.03184475749731064`
- `active_budget`: `0.002052395837381482`
- `tape_budget`: `0.001454908400774002`
- `layer_action_diversity`: `0.0`
- `train_acc`: `0.453125`
- `sim_disabled_delta`: `0.0028183460235595703`
- `choice_without_sim_delta`: `0.0028183460235595703`
- `program_recovery_rate`: `0.0`
- `expected_edge_recovery`: `0.0`
- `expected_any_recovery`: `0.0126953125`
- `expected_candidate_present`: `1.0`
- `expected_edge_choice_mass`: `0.010717557743191719`
- `expected_edge_active`: `0.19648528099060059`
- `transform_mass`: `0.5566303133964539`
- `skip_mass`: `0.22554084658622742`
- `disable_mass`: `0.21782884001731873`
- `choice_entropy`: `1.461320400238037`
- `primitive_embedding_rank`: `25.0`
- `primitive_pair_cos_mean`: `0.47301238775253296`
- `primitive_pair_cos_max`: `0.9875321388244629`
- `usage_entropy`: `0.29055923223495483`
- `semantic_grid_mismatch`: `0.400634765625`
- `grid_candidate_usage`: `0.0`
- `semantic_candidate_usage`: `0.0`
- `usage_candidate_usage`: `0.0`
- `random_candidate_usage`: `0.0`
- `edge_scale_mean`: `0.9451497793197632`
- `cell_output_gate_mean`: `0.5501842498779297`
- `cell_tape_weight_mean`: `0.06314326077699661`
- `edge_pair_bias_expected`: `0.0`
- `edge_pair_bias_std`: `0.0`
- `write_pair_bias_expected`: `0.0`
- `write_pair_bias_std`: `0.0`
- `phase_pair_bias_expected`: `0.0`
- `phase_pair_bias_std`: `0.0`
- `cell_output_pair_bias_expected`: `0.0`
- `cell_output_pair_bias_std`: `0.0`
